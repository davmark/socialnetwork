<?php $__env->startSection('content'); ?>
<?php echo $__env->make('site.layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#userRegistrationTab">User registration</a></li>
    <li class=""><a data-toggle="tab" href="#companyRegistrationTab">Company registration</a></li>
    <li class=""><a data-toggle="tab" href="#festivalRegistrationTab">Festival registration</a></li>
</ul>

<div class="tab-content">
    <?php echo $__env->make('alerts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div id="userRegistrationTab" class="tab-pane fade in active">
        <h3>User</h3>
        <?php echo $__env->make('auth.forms.userRegisterForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div id="companyRegistrationTab" class="tab-pane fade">
        <h3>Company</h3>
        <?php echo $__env->make('auth.forms.companyRegisterForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div id="festivalRegistrationTab" class="tab-pane fade">
        <h3>Festival</h3>
        <?php echo $__env->make('auth.forms.festivalRegisterForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo Html::script('auth/js/register.js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>