<div class="col-md-12 pull-right">
    <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo e(url('/')); ?>">Site</a></li>
        <li><a href="<?php echo e(url('user')); ?>">My page</a></li>
        <li><a href="<?php echo e(url('user/settings')); ?>">Settings</a></li>
        <li><a href="<?php echo e(url('user/search')); ?>">Search</a></li>
        <li><a href="<?php echo e(url('user/friends')); ?>">Friends</a></li>
        <?php if(\Auth::guard('user')->check()): ?>
        <li><a href="<?php echo e(url('auth/logout/user')); ?>">Logout</a></li>
        <?php endif; ?>
    </ul>
</div>