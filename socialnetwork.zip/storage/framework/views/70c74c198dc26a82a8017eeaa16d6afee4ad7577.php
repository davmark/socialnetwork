<div class="form-group">
    <?php echo $__env->make('layouts/cropper/cropper',['action'=>url('festival/settings/crop-avatar'),'avatar'=>($user->avatar)? url('').'/festivals/imgs/'.$user->avatar : url('').'/main/imgs/festival-default-avatar.png'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>


<?php echo Form::model($user,['url'=>'festival/settings/update-info','method'=>'POST','files'=>true]); ?>

<!--    <div class="form-group">
        <div>
            <img src="<?php if($user->avatar): ?> <?php echo e(url('')); ?>/festivals/imgs/<?php echo e($user->avatar); ?> <?php else: ?> <?php echo e(url('')); ?>/main/imgs/festival-default-avatar.png <?php endif; ?>" class="img-thumbnail img-responsive avatar__default" />
        </div>

        <div>
            <?php echo Form::label('file', 'Select file', ['class'=>'control-label']); ?>

            <?php echo Form::file('file', ['class'=>'form-control logo__file__input']); ?>

        </div>
    </div>-->
    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <?php echo Form::label('name', 'Name', ['class'=>'control-label']); ?>

        <?php echo Form::text('name', NULL, ['class'=>'form-control']); ?>

    </div>
    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <?php echo Form::label('email', 'Email', ['class'=>'control-label']); ?>

        <?php echo Form::text('email', NULL, ['class'=>'form-control']); ?>

    </div>
    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <?php echo Form::label('country_id', 'Country', ['class'=>'control-label']); ?>

        <?php echo Form::select('country_id', \App\Helpers\ActionClass::getCountries(), NULL, ['class'=>'form-control']); ?>

    </div>
    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <?php echo Form::label('start_time', 'Start date', ['class'=>'control-label']); ?>

        <?php echo Form::text('start_time', NULL, ['class'=>'form-control']); ?>

    </div>
    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <?php echo Form::label('end_time', 'End date', ['class'=>'control-label']); ?>

        <?php echo Form::text('end_time', NULL, ['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::submit('Update',['class'=>'form-control']); ?>

    </div>
<?php echo Form::close(); ?>