<tr class="info">
    <td><?php echo e($result->username); ?></td>
    <td><?php echo e($result->email); ?></td>
    <td>
        <?php if($friend = $result->getRequest($user->id,$result->id)): ?>
            <?php if($friend['accept']): ?>
                <button class="btn btn-info unfriend__request" data-user_id = '<?php echo e($result->id); ?>'>Unfriend</button>
            <?php else: ?>
                <?php if($friend['from']): ?>
                <p class="warning">Request sent</p>
                <?php else: ?>
                    <button class="btn btn-warning accept__request" data-user_id = '<?php echo e($result->id); ?>'>Accept invitation</button>
                    <button class="btn btn-danger cancel__request" data-user_id = '<?php echo e($result->id); ?>'>Cancel</button>
                <?php endif; ?>
            <?php endif; ?>
        <?php else: ?>
        <button class="btn btn-success send__request" data-user_id = '<?php echo e($result->id); ?>'>Send request</button>
        <?php endif; ?>
    </td>
</tr>
