<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title><?php echo $__env->yieldContent('title', 'Social Network'); ?></title>
        <?php echo Html::style('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css'); ?>

        <?php echo Html::style('//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.min.css'); ?>

        <?php echo $__env->yieldContent('css'); ?>
    </head>
    <body>
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
            <div id="ajax__request__data"
                 data-url="<?php echo e(url('/')); ?>"
                 data-token="<?php echo e(csrf_token()); ?>"
                 ></div>
        </div>
        <?php echo Html::script('https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js'); ?>

        <?php echo Html::script('http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js'); ?>

        <?php echo Html::script('//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js'); ?>

        <?php echo Html::script('main/js/common.js'); ?>

        <?php echo $__env->yieldContent('js'); ?>
    </body>
</html>