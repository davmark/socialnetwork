<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('alerts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div>
        <address>
            <strong><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> (username - <?php echo e($user->username); ?>)</strong><br>
            <p>Country - <?php echo e(($user->country)?$user->country->name:'Country is empty'); ?></p>
            <a href="mailto:#"><?php echo e($user->email); ?></a>
        </address>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>