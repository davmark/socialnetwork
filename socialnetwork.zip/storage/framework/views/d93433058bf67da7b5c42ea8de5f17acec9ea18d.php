<div class="form-group">
    <?php echo $__env->make('layouts/cropper/cropper',['action'=>url('user/settings/crop-avatar'),'avatar'=>($user->avatar)? url('').'/users/imgs/'.$user->avatar : url('').'/main/imgs/user-default-avatar.png'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php echo Form::model($user,['url'=>'user/settings/update-info','method'=>'POST','files'=>true]); ?>


<!--    <div class="form-group">
        <div>
            <img src="<?php if($user->avatar): ?> <?php echo e(url('')); ?>/users/imgs/<?php echo e($user->avatar); ?> <?php else: ?> <?php echo e(url('')); ?>/main/imgs/user-default-avatar.png <?php endif; ?>" class="img-thumbnail img-responsive avatar__default" />
        </div>

        <div>
            <?php echo Form::label('file', 'Select file', ['class'=>'control-label']); ?>

            <?php echo Form::file('file', ['class'=>'form-control avatar__file__input']); ?>

        </div>
    </div>-->

    <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
        <?php echo Form::label('first_name', 'Firts Name', ['class'=>'control-label']); ?>

        <?php echo Form::text('first_name', NULL, ['class'=>'form-control']); ?>

    </div>

    <div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
        <?php echo Form::label('last_name', 'Last Name', ['class'=>'control-label']); ?>

        <?php echo Form::text('last_name', NULL, ['class'=>'form-control']); ?>

    </div>

    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <?php echo Form::label('email', 'Email', ['class'=>'control-label']); ?>

        <?php echo Form::text('email', NULL, ['class'=>'form-control']); ?>

    </div>

    <div class="form-group<?php echo e($errors->has('occupation') ? ' has-error' : ''); ?>">
        <?php echo Form::label('occupation', 'Occupation', ['class'=>'control-label']); ?>

        <?php echo Form::select('occupation', [1,2,3], NULL, ['class'=>'form-control']); ?>

    </div>

    <div class="form-group<?php echo e($errors->has('country_id') ? ' has-error' : ''); ?>">
        <?php echo Form::label('country_id', 'Change country', ['class'=>'control-label']); ?>

        <?php echo Form::select('country_id', \App\Helpers\ActionClass::getCountries(), NULL, ['class'=>'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::submit('Update',['class'=>'form-control']); ?>

    </div>

<?php echo Form::close(); ?>