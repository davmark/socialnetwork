<div class="row">
    <div class="col-lg-6">
        <?php echo Form::open(['url'=>'auth/register', 'method' =>'POST','class'=>'form-vertical']); ?>

            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <?php echo Form::label('first_name', 'Firts Name', ['class'=>'control-label']); ?>

                <?php echo Form::text('first_name', NULL, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <?php echo Form::label('last_name', 'Last Name', ['class'=>'control-label']); ?>

                <?php echo Form::text('last_name', NULL, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <?php echo Form::label('email', 'Email', ['class'=>'control-label']); ?>

                <?php echo Form::text('email', NULL, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <?php echo Form::label('occupation', 'Occupation', ['class'=>'control-label']); ?>

                <?php echo Form::select('occupation', [1,2,3], NULL, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <?php echo Form::label('country_id', 'Country', ['class'=>'control-label']); ?>

                <?php echo Form::select('country_id', $countries, NULL, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <?php echo Form::label('password', 'Choose a password', ['class'=>'control-label']); ?>

                <?php echo Form::password('password', ['class'=>'form-control']); ?>

            </div>
            <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <?php echo Form::label('password_confirmation', 'Confirm password', ['class'=>'control-label']); ?>

                <?php echo Form::password('password_confirmation', ['class'=>'form-control']); ?>

            </div>
            <?php echo Form::hidden('role', 'user'); ?>

            <div class="form-group">
                <?php echo Form::button('Regitering',['type'=>'submit','class'=>'btn btn-default btn-submit']); ?>

            </div>
        <?php echo Form::close(); ?>

    </div>
</div>