<div class="col-md-12 pull-right">
    <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo e(url('/')); ?>">Site</a></li>
        <li><a href="<?php echo e(url('festival')); ?>">My Page</a></li>
        <li><a href="<?php echo e(url('festival/settings')); ?>">Settings</a></li>
        <?php if(\Auth::guard('festival')->check()): ?>
        <li><a href="<?php echo e(url('auth/logout/festival')); ?>">Logout</a></li>
        <?php endif; ?>
    </ul>
</div>