<div class="col-md-12 pull-right">
    <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
        <li><a href="<?php echo e(url('home/about')); ?>">About</a></li>
        <li><a href="<?php echo e(url('home/contact')); ?>">Contuct us</a></li>
        <?php if(\Auth::guard('user')->check() or \Auth::guard('company')->check() or \Auth::guard('festival')->check()): ?>
        <li><a href="<?php echo e(url('auth/logout')); ?>">Logout</a></li>
        <?php endif; ?>
        <li><a href="<?php echo e(url('auth/login')); ?>">Login</a></li>
        <li><a href="<?php echo e(url('auth/register')); ?>">Registration</a></li>
    </ul>
</div>