<?php echo Form::open([ 'url' => 'festival/settings/change-password', 'method' => 'POST' ]); ?>

    <div class="form-group">
        <?php echo Form::label('password', 'New Password', ['class'=>'control-label']); ?>

        <?php echo Form::text('password', NULL, ['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::submit('Cahnge Password',['class'=>'form-control']); ?>

    </div>
<?php echo Form::close(); ?>