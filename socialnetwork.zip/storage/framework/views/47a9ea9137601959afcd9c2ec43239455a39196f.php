<?php echo Form::model($user,['url'=>'user/settings/update-info','method'=>'POST']); ?>

    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <?php echo Form::label('first_name', 'Firts Name', ['class'=>'control-label']); ?>

            <?php echo Form::text('first_name', NULL, ['class'=>'form-control']); ?>

        </div>
        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <?php echo Form::label('last_name', 'Last Name', ['class'=>'control-label']); ?>

            <?php echo Form::text('last_name', NULL, ['class'=>'form-control']); ?>

        </div>
        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <?php echo Form::label('email', 'Email', ['class'=>'control-label']); ?>

            <?php echo Form::text('email', NULL, ['class'=>'form-control']); ?>

        </div>
        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <?php echo Form::label('occupation', 'Occupation', ['class'=>'control-label']); ?>

            <?php echo Form::select('occupation', [1,2,3], NULL, ['class'=>'form-control']); ?>

        </div>
        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <?php echo Form::label('country_id', 'Change country', ['class'=>'control-label']); ?>

            <?php echo Form::select('country_id', \App\Helpers\ActionClass::getCountries(), NULL, ['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::submit('Update',['class'=>'form-control']); ?>

        </div>
<?php echo Form::close(); ?>