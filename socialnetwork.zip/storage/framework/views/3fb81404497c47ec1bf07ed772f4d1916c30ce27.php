<?php echo Form::open([ 'url'=>url('user/timeline/create-status'), 'method'=>'POST', ]); ?>

    <div class="form-group">
        <?php echo Form::textarea('text',null, [ 'class' => 'form-control', 'cols'=>'2', 'rows' => '3' ]); ?>

    </div>

    <div class="form-group">
        <?php echo Form::button('Create', [ 'type' => 'submit', 'class' => 'btn btn-info' ]); ?>

    </div>
    
<?php echo Form::close(); ?>