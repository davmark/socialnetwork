<?php echo Form::open([ 'url' => 'user/search/index', 'method' => 'POST' ]); ?>

    <div class="form-group">
        <?php echo Form::label('search_result', 'Enter user data', ['class'=>'control-label']); ?>

        <?php echo Form::text('search_result', NULL, ['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::submit('Search',['class'=>'form-control']); ?>

    </div>
<?php echo Form::close(); ?>