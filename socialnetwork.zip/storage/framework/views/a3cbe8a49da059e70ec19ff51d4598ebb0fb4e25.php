<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('alerts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div>
        <h2>User Info</h2>
        <?php echo $__env->make('users/settings/forms/info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div>
        <h2>Change Password</h2>
        <?php echo $__env->make('users/settings/forms/password', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>