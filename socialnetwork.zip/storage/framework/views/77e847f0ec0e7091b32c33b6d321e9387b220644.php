<div class="row">
    <div class="col-lg-6">
        <?php echo Form::open(['url'=>'auth/register', 'method' =>'POST','class'=>'form-vertical']); ?>

            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <?php echo Form::label('name', 'Name', ['class'=>'control-label']); ?>

                <?php echo Form::text('name', NULL, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <?php echo Form::label('email', 'Email', ['class'=>'control-label']); ?>

                <?php echo Form::text('email', NULL, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <?php echo Form::label('country_id', 'Country', ['class'=>'control-label']); ?>

                <?php echo Form::select('country_id', $countries, NULL, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <?php echo Form::label('start_time', 'Start date', ['class'=>'control-label']); ?>

                <?php echo Form::text('start_time', NULL, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <?php echo Form::label('end_time', 'End date', ['class'=>'control-label']); ?>

                <?php echo Form::text('end_time', NULL, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <?php echo Form::label('password', 'Choose a password', ['class'=>'control-label']); ?>

                <?php echo Form::password('password', ['class'=>'form-control']); ?>

            </div>
            <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <?php echo Form::label('password_confirmation', 'Confirm password', ['class'=>'control-label']); ?>

                <?php echo Form::password('password_confirmation', ['class'=>'form-control']); ?>

            </div>
        <?php echo Form::hidden('role', 'festival'); ?>

            <div class="form-group">
                <?php echo Form::submit('Sign up',['class'=>'btn btn-default']); ?>

            </div>
        <?php echo Form::close(); ?>

    </div>
</div>