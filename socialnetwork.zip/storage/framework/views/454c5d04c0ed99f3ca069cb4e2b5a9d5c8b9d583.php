

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('companies.layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('alerts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div>
        <div>
            <img src="<?php if($user->avatar): ?> <?php echo e(url('')); ?>/companies/imgs/<?php echo e($user->avatar); ?> <?php else: ?> <?php echo e(url('')); ?>/main/imgs/company-default-avatar.png <?php endif; ?>" class="img-thumbnail img-responsive avatar__default" />
        </div>
      <address>
        <strong><?php echo e($user->username); ?>, (username  -  <?php echo e($user->username); ?>)</strong><br>
        <p>Country - <?php echo e($user->country->name); ?></p>
        <a href="mailto:#"><?php echo e($user->email); ?></a>
      </address>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>