<td><?php echo e($friend['first_name']); ?></td>
<td><?php echo e($friend['last_name']); ?></td>
<td><?php echo e($friend['email']); ?></td>