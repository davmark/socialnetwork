<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('alerts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <div>
        <h2>Friends list</h2>

        <table class="table">
            <thead>
                <tr>
                    <td>First name</td>
                    <td>Last name</td>
                    <td>Email</td>
                    <td>Unfriend</td>
                </tr>
            </thead>
            <tbody>
                <?php foreach($firendsList['friends'] as $friend): ?>
                <tr class="success">
                    <?php echo $__env->make('users/friends/items/friend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <td><button>Unfriend</button></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div><hr/>

    <div>
        <h2>Request sent from me</h2>
        <table class="table">
            <thead>
                <tr>
                    <td>First name</td>
                    <td>Last name</td>
                    <td>Email</td>
                </tr>
            </thead>
            <tbody>
                <?php foreach($firendsList['from'] as $friend): ?>
                <tr class="warning">
                    <?php echo $__env->make('users/friends/items/friend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div><hr/>

    <div>
        <h2>Request sent to me</h2>

        <table class="table">
            <thead>
                <tr>
                    <td>First name</td>
                    <td>Last name</td>
                    <td>Email</td>
                    <td>Request to me</td>
                </tr>
            </thead>
            <tbody>
                <?php foreach($firendsList['to'] as $friend): ?>
                <tr class="info">
                    <?php echo $__env->make('users/friends/items/friend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <td><button>Cancel</button></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div><hr/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo Html::script('users/js/friends/main.js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>