<div class="col-md-12 pull-right">
    <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo e(url('/')); ?>">Site</a></li>
        <li><a href="<?php echo e(url('company')); ?>">My Page</a></li>
        <li><a href="<?php echo e(url('company/settings')); ?>">Settings</a></li>
        <?php if(\Auth::guard('company')->check()): ?>
        <li><a href="<?php echo e(url('auth/logout/company')); ?>">Logout</a></li>
        <?php endif; ?>
    </ul>
</div>