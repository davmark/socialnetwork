

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users/layouts/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('alerts/messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <div class="col-md-6">
            <?php echo $__env->make('users/layouts/timelinemenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-6">
            <h3>Create status</h3>
            <?php echo $__env->make('users/timelines/forms/status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        
        <div class="">
            <h3>My Status</h3>
            <?php if($lastStatus): ?>
                <p><?php echo e($lastStatus->text); ?></p>
            <?php else: ?>
                <p>Not yet status</p>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>