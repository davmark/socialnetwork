

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('alerts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div>
        <h2>Search user by username or first name and last name</h2>
        <?php echo $__env->make('users/searches/forms/users', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div>
        <table class="table">
            <thead>
                <tr>
                    <td>Username</td>
                    <td>Email</td>
                    <td>Friend request</td>
                </tr>
            </thead>
            <tbody>
                <?php foreach($results as $result): ?>
                    <?php echo $__env->make('users/searches/items/user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo Html::script('users/js/search/main.js'); ?>

    <?php echo Html::script('users/js/friends/main.js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>