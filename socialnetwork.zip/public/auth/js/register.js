$('#start_date').datepicker({
    format:'yyyy-mm-dd'
});
$('#end_date').datepicker({
    format:'yyyy-mm-dd'
});