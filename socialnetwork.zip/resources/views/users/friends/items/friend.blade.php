<td>{{$friend['first_name']}}</td>
<td>{{$friend['last_name']}}</td>
<td>{{$friend['email']}}</td>