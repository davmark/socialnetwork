@extends('layouts.index')

@section('title')
    Social network - Home
@stop

@section('css')
    
@stop

@section('content')
@include('site.layouts.menu')
<div class="row">
    <div class="col-md-12">
        <h3>Welcome to Social Network</h3>
        <p>The page is under construction</p>
    </div>
</div>
@endsection

@section('js')
    
@stop