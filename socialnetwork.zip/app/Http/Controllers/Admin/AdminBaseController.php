<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Routing\Controller;

class AdminBaseController extends Controller
{
    
}